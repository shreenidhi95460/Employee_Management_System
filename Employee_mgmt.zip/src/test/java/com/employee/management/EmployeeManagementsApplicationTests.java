package com.employee.management;

import com.employee.management.persistence.dao.EmployeeDetailsDao;
import com.employee.management.persistence.dao.UserLoginDao;
import com.employee.management.persistence.model.UserLogin;
import com.employee.management.service.Implementation.EmployeeServiceImplementation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.AuthenticationManager;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@MockitoSettings(strictness= Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
class EmployeeManagementsApplicationTests {


	private EmployeeServiceImplementation employeeServiceImplementation;

	private UserLogin userLogin;

	@Mock
	private EmployeeDetailsDao employeeDao;


	@Mock
	private AuthenticationManager authenticationManager;

	@Mock
	private UserLoginDao userLoginDao;

	@BeforeEach
	void setUp(){
		this.employeeServiceImplementation=new  EmployeeServiceImplementation(this.employeeDao);
		userLogin=new UserLogin();
		userLogin.setUsername("shubham");

	}

	@Test
	void getDetails(){
		employeeServiceImplementation.getAllDetails();
		verify(employeeDao).findAll();
	}

	@Test
	void loginTest() {
		when(userLoginDao.findByUsername("harsh")).thenReturn(userLogin);

		authenticationManager.authenticate()

	}

}
