package com.employee.management.security;

import com.employee.management.persistence.DataTransfer.UserPrinciple;
import com.employee.management.persistence.dao.UserLoginDao;
import com.employee.management.persistence.model.UserLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserLoginDao userLoginDao;

    public CustomUserDetailsService(UserLoginDao userLoginDao) {

        this.userLoginDao = userLoginDao;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserLogin userLogin = userLoginDao.findByUsername(username);

        if(userLogin == null) {
            System.out.println("User not found");
            throw new UsernameNotFoundException("User Not found");
        }
        return new UserPrinciple(userLogin);

    }
}
