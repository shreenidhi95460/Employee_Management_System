package com.employee.management.security;


import com.employee.management.persistence.dao.UserLoginDao;
import com.employee.management.persistence.model.UserLogin;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtTokenProvider {

    @Autowired
    private UserLoginDao userLoginDao;

    private String secretKey = "";

    public JwtTokenProvider(){

        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("HmacSHA256");
            SecretKey sk = keyGen.generateKey();
            secretKey = Base64.getEncoder().encodeToString(sk.getEncoded());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }


    public String generateToken(String username) {
        Map<String, Object> claims = new HashMap<>();
       // claims.put("token", token);
        return Jwts.builder()
                .setClaims(claims) // Use setClaims() to add claims
                .setSubject(username)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 60 * 60 * 30 * 1000)) // Adjust expiration time calculation
                .signWith(getKey()) // Method to retrieve the signing key
                .compact();
    }

    private SecretKey getKey() {

       byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public String extractUserName(String token) {

        return extractClaims(token, Claims::getSubject);
    }

//    public String extractToken(String token) {
//
//        return extractClaims(token,  )
//    }



    private <T> T extractClaims(String token, Function<Claims,T> claimResolver) {
        final Claims claims = extractAllClaim(token);
        return claimResolver.apply(claims);
    }

    private Claims extractAllClaim(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public  boolean  validateToken(String token, UserDetails userDetails) {

        final String userName = extractUserName(token);
        UserLogin user = userLoginDao.findByUsername(userName);

        return (userName.equals(userDetails.getUsername()) && !isTokenExpired(token) && token.equals(user.getToken()) );
    }

    private boolean isTokenExpired(String token) {

        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {

        return extractClaims(token, Claims::getExpiration);
    }
}
