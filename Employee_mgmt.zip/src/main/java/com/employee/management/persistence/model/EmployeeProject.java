package com.employee.management.persistence.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "employee_project_details")
public class EmployeeProject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_project_details_id")
    private Long employeeprojectDetailsId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_emp_id")
    @JsonIgnore
    private EmployeeDetails employee;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_project_id")
    @JsonIgnore
    private Project project;

    @Column(length = 100)
    private String role;
}
