package com.employee.management.persistence.DataTransfer;


import com.employee.management.persistence.model.Department;
import com.employee.management.persistence.model.EmployeeDetails;
import com.employee.management.persistence.model.JobDetails;
import lombok.Data;

@Data
public class Register {

    private String first_name;

    private String last_name;

    private String dob;

    private Integer gender;

    private Department department;

    private JobDetails jobDetails;

    private Long hireDate;

    private String email;

    private String address;

    private EmployeeDetails manager;

    private String username;

    private String password;

    private EmployeeDetails userLoginDetails;

    private Long lastLogin;




}
