package com.employee.management.persistence.dao;

import com.employee.management.persistence.model.UserLogin;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserLoginDao extends JpaRepository<UserLogin, Long> {

    UserLogin findByUsername(String username);

    Optional<UserLogin> findByUsernameAndPassword(String username, String password);

}
