package com.employee.management.persistence.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "DEPARTMENT")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long dept_id;

    @Column(length = 100)
    private String dept_name;

    @Column(length = 100)
    private String location;
}
