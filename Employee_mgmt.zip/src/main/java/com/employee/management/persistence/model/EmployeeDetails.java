package com.employee.management.persistence.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Employee_Details")
public class EmployeeDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_id")
    private Long empId;

    private String first_name;

    private String last_name;

    private String dob;

    private Integer gender;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_dept_id")
    @JsonIgnore
    private Department department;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_job_title_id")
    @JsonIgnore
    private JobDetails jobDetails;

    @Column(name = "hire_date")
    private Long hireDate;

    @Column(unique = true)
    private String email;

    @Column(name = "phone_number")
    private Long phoneNumber=(long) (Math.random()*Math.pow(10, 10));

    private String address;

    private Double salary=Math.random()*1000;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="fk_manager_id")
    @JsonIgnore
    private EmployeeDetails manager;


}
