package com.employee.management.persistence.dao;

import com.employee.management.persistence.model.EmployeeDetails;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeDetailsDao extends JpaRepository<EmployeeDetails, Long> {

    Boolean existsByEmail(String email);

   // Page<EmployeeDetails> findAll(Pageable pageable);


}
