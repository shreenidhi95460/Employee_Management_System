package com.employee.management.persistence.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Job_title_Details")
public class JobDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long job_title_id;
    @Column(length = 100)
    private String title_name;
    private String description;
}
