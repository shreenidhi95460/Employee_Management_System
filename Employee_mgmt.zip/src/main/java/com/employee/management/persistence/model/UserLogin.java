package com.employee.management.persistence.model;

import com.employee.management.persistence.dao.UserLoginDao;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "user_table")
@AllArgsConstructor
public class UserLogin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long login_id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JsonIgnore
    @JoinColumn(name="fk_emp_id")
    private EmployeeDetails employeeDetails;

    @Column(unique = true)
    private String username;

    @Column(unique = true)
    private String password;

    @Column(name = "is_active")
    private Boolean isActive=true;

    @Column(name = "last_login")
    private Long lastLogin;

    private String token;

    public UserLogin(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public UserLogin() {
    }

    public UserLogin(UserLoginDao userLoginDao) {
    }
}
