package com.employee.management.controller.response;


import com.employee.management.persistence.DataTransfer.PageRequests;
import com.employee.management.persistence.model.EmployeeDetails;
import com.employee.management.service.Implementation.EmployeeServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employee")
public class UserDetailsController {

    @Autowired
    private EmployeeServiceImplementation employeeServiceImplementation;

    @GetMapping(value="/alldetails")
    public List<EmployeeDetails> getAllDetails(){

        return employeeServiceImplementation.getAllDetails();
    }
    //pagination
    @GetMapping("/getdetails")
    public Page<EmployeeDetails> getUSerDetails(@RequestBody PageRequests dto){

        return employeeServiceImplementation.getAllUserDetails(dto);

    }


}
