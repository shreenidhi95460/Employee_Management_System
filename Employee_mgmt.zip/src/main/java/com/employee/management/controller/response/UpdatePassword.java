package com.employee.management.controller.response;


import com.employee.management.persistence.DataTransfer.Login;
import com.employee.management.service.Implementation.EmployeeServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/employee")
public class UpdatePassword {

    @Autowired
    private EmployeeServiceImplementation employeeServiceImplementation;

   @PutMapping("/updateUsingUsername")
    public String updatePassword(@RequestBody Login login) {

        return employeeServiceImplementation.updatePassword(login);
    }
}
