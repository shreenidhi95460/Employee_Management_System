package com.employee.management.controller.response;


import com.employee.management.persistence.DataTransfer.Login;
import com.employee.management.persistence.DataTransfer.LoginMessage;
import com.employee.management.persistence.model.UserLogin;
import com.employee.management.service.EmployeeService;
import com.employee.management.service.Implementation.EmployeeServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/employee")
public class LoginController {

    @Autowired
    private EmployeeServiceImplementation serviceImplementation;

    @PostMapping(value = "/login")
    public String  login(@RequestBody Login userLogin){

//        LoginMessage message = serviceImplementation.login(userLogin);
//
//     return ResponseEntity.ok(message);
        return serviceImplementation.login(userLogin);
    }

}
