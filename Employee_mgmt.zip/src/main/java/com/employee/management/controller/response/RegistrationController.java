package com.employee.management.controller.response;


import com.employee.management.EmployeeManagementsApplication;
import com.employee.management.persistence.DataTransfer.Register;
import com.employee.management.persistence.model.EmployeeDetails;
import com.employee.management.service.EmployeeService;
import com.employee.management.service.Implementation.EmployeeServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employee")
public class RegistrationController {

    @Autowired
    private EmployeeServiceImplementation employeeServiceImplementation;

    @PostMapping(value = "/register")
    public EmployeeDetails register(@RequestBody Register emp) {
       EmployeeDetails employee = employeeServiceImplementation.register(emp);
       return employee;
    }


}
