package com.employee.management.service;

import com.employee.management.persistence.DataTransfer.Login;
import com.employee.management.persistence.DataTransfer.LoginMessage;
import com.employee.management.persistence.DataTransfer.PageRequests;
import com.employee.management.persistence.DataTransfer.Register;
import com.employee.management.persistence.model.EmployeeDetails;
import com.employee.management.persistence.model.UserLogin;
import org.springframework.data.domain.Page;

import java.util.List;

public interface EmployeeService {

    public EmployeeDetails register(Register register);

    List<EmployeeDetails> getAllDetails();


    String login(Login userLogin);

    String updatePassword(Login login);

   // Page<EmployeeDetails> getUsers(int pageNumber, int pageSize, String sortBy, String sortDirection);

    Page<EmployeeDetails> getAllUserDetails(PageRequests dto);
}
