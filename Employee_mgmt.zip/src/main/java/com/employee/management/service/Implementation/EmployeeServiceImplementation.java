package com.employee.management.service.Implementation;

import com.employee.management.exception.ApiException;
import com.employee.management.persistence.DataTransfer.Login;
import com.employee.management.persistence.DataTransfer.LoginMessage;
import com.employee.management.persistence.DataTransfer.PageRequests;
import com.employee.management.persistence.DataTransfer.Register;
import com.employee.management.persistence.dao.EmployeeDetailsDao;
import com.employee.management.persistence.dao.UserLoginDao;
import com.employee.management.persistence.model.EmployeeDetails;
import com.employee.management.persistence.model.UserLogin;
import com.employee.management.security.JwtTokenProvider;
import com.employee.management.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImplementation implements EmployeeService {

    @Autowired
    private EmployeeDetailsDao employeeDetailsDao;

    @Autowired
    private UserLoginDao userLoginDao;

    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private PasswordEncoder passwordEncoder;


    @Override
    public EmployeeDetails register(Register register) {


        if(employeeDetailsDao.existsByEmail(register.getEmail())) {
            throw new ApiException("Email Already Exists!!");
        }

        EmployeeDetails emp = new EmployeeDetails();
        UserLogin login = new UserLogin();

        emp.setFirst_name(register.getFirst_name());
        emp.setLast_name((register.getLast_name()));
        emp.setDob(register.getDob());
        emp.setGender(register.getGender());
        emp.setDepartment(register.getDepartment());
        emp.setJobDetails(register.getJobDetails());
        emp.setHireDate(register.getHireDate());
        emp.setEmail(register.getEmail());
        emp.setAddress(register.getAddress());
        emp.setManager(register.getManager());
        login.setUsername(register.getUsername());
        login.setPassword(passwordEncoder.encode(register.getPassword()));
        login.setEmployeeDetails(register.getUserLoginDetails());
        login.setLastLogin(register.getLastLogin());

        EmployeeDetails emp1 = employeeDetailsDao.save(emp);
        userLoginDao.save(login);
        return emp1;
    }

    @Override
    public List<EmployeeDetails> getAllDetails() {

        return employeeDetailsDao.findAll();
    }


    public EmployeeServiceImplementation(EmployeeDetailsDao employeeDetailsDao) {
        this.employeeDetailsDao=employeeDetailsDao;
    }

    @Override
    public String login(Login userLogin) {

        Optional<UserLogin> user = Optional.ofNullable(userLoginDao.findByUsername(userLogin.getUsername()));
        Authentication authentication = authManager.authenticate
                (new UsernamePasswordAuthenticationToken(userLogin.getUsername(), userLogin.getPassword()));
        if (authentication.isAuthenticated()) {
            UserLogin token = user.get();
            token.setToken(jwtTokenProvider.generateToken(userLogin.getUsername()));
            userLoginDao.save(token);
            return jwtTokenProvider.generateToken(userLogin.getUsername());
        } else {
            return "fail";
        }
    }

    @Override
    public String updatePassword(Login login) {



            Optional<UserLogin> user = Optional.ofNullable(userLoginDao.findByUsername(login.getUsername()));
            if(user.isPresent()) {
                UserLogin passwordUpdate = user.get();
                String encoded = passwordEncoder.encode(login.getPassword());

                passwordUpdate.setPassword(encoded);
                userLoginDao.save(passwordUpdate);
                return "Password updated successfully for the user "+login.getUsername();
            } else throw  new ApiException("Username not found!!");
    }


    @Override
    public Page<EmployeeDetails> getAllUserDetails(PageRequests dto) {
        Pageable pageable = new PageRequests().getPageable(dto);
        Page<EmployeeDetails>  page = employeeDetailsDao.findAll(pageable);
        return page;
    }

}
